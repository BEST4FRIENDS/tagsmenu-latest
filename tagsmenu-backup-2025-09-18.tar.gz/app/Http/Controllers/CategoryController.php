<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    public function index()
    {
        // Lädt das Restaurant des eingeloggten Benutzers
        $restaurant = Auth::user()->restaurant;
        
        // Lädt NUR die Kategorien, die zu DIESEM Restaurant gehören
        $categories = $restaurant ? $restaurant->categories()->with('translations')->get() : collect();

        return view('categories.index', ['categories' => $categories]);
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name_de' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
            'name_hu' => 'nullable|string|max:255',
            'name_sk' => 'nullable|string|max:255',
        ]);

        $restaurant = Auth::user()->restaurant;
        
        // Erstellt die Kategorie direkt für das Restaurant des eingeloggten Benutzers
        $category = $restaurant->categories()->create([]);

        $this->updateTranslations($category, $validated);

        return redirect()->route('categories.index')->with('success', 'Kategorie erfolgreich erstellt!');
    }

    public function edit(Category $category)
    {
        // Sicherheits-Check: Gehört die Kategorie zum Restaurant des Benutzers?
        if ($category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403); // Zugriff verweigern
        }
        
        $category->load('translations');
        return view('categories.edit', ['category' => $category]);
    }

    public function update(Request $request, Category $category)
    {
        // Sicherheits-Check
        if ($category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403);
        }

        $validated = $request->validate([
            'name_de' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
            'name_hu' => 'nullable|string|max:255',
            'name_sk' => 'nullable|string|max:255',
        ]);

        $this->updateTranslations($category, $validated);

        return redirect()->route('categories.index')->with('success', 'Kategorie erfolgreich aktualisiert!');
    }

    public function destroy(Category $category)
    {
        // Sicherheits-Check
        if ($category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403);
        }
        
        $category->delete();
        return redirect()->route('categories.index')->with('success', 'Kategorie erfolgreich gelöscht!');
    }

    // Private Hilfsfunktion, um Code-Wiederholung zu vermeiden
    private function updateTranslations(Category $category, array $validated)
    {
        if (!empty($validated['name_de'])) {
            $category->translations()->updateOrCreate(['locale' => 'de'], ['name' => $validated['name_de']]);
        }
        if (!empty($validated['name_en'])) {
            $category->translations()->updateOrCreate(['locale' => 'en'], ['name' => $validated['name_en']]);
        }
        if (!empty($validated['name_hu'])) {
            $category->translations()->updateOrCreate(['locale' => 'hu'], ['name' => $validated['name_hu']]);
        }
        if (!empty($validated['name_sk'])) {
            $category->translations()->updateOrCreate(['locale' => 'sk'], ['name' => $validated['name_sk']]);
        }
    }
}