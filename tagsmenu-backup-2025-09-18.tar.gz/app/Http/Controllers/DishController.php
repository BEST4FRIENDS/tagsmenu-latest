<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Dish;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class DishController extends Controller
{
    public function index()
    {
        $restaurant = Auth::user()->restaurant;
        // Lädt nur Kategorien (und deren Gerichte), die zum Restaurant des Benutzers gehören
        $categories = $restaurant ? $restaurant->categories()->with('dishes.translations')->get() : collect();
        return view('dishes.index', ['categories' => $categories]);
    }

    public function create()
    {
        $restaurant = Auth::user()->restaurant;
        // Zeigt nur Kategorien aus dem eigenen Restaurant im Dropdown an
        $categories = $restaurant ? $restaurant->categories()->with('translations')->get() : collect();
        return view('dishes.create', ['categories' => $categories]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'price' => 'required|integer|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_special' => 'nullable|boolean',
            'is_vegetarian' => 'nullable|boolean',
            'name_de' => 'required|string|max:255',
            'description_de' => 'nullable|string',
            'name_en' => 'nullable|string|max:255',
            'description_en' => 'nullable|string',
            'name_hu' => 'nullable|string|max:255',
            'description_hu' => 'nullable|string',
            'name_sk' => 'nullable|string|max:255',
            'description_sk' => 'nullable|string',
        ]);

        // Sicherheits-Check: Gehört die ausgewählte Kategorie zum Restaurant des Benutzers?
        $category = Category::findOrFail($validated['category_id']);
        if ($category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403); // Zugriff verweigern
        }

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('dishes', 'public');
        }

        $dish = Dish::create([
            'category_id' => $validated['category_id'],
            'price' => $validated['price'],
            'image_url' => $imagePath,
            'is_special' => $request->has('is_special'),
            'is_vegetarian' => $request->has('is_vegetarian'),
        ]);

        $this->updateTranslations($dish, $validated);

        return redirect()->route('dishes.index')->with('success', 'Gericht erfolgreich erstellt!');
    }

    public function edit(Dish $dish)
    {
        // Sicherheits-Check: Gehört das Gericht zum Restaurant des Benutzers?
        if ($dish->category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403);
        }

        $dish->load('translations');
        $restaurant = Auth::user()->restaurant;
        $categories = $restaurant ? $restaurant->categories()->with('translations')->get() : collect();

        return view('dishes.edit', [
            'dish' => $dish,
            'categories' => $categories
        ]);
    }

    public function update(Request $request, Dish $dish)
    {
        // Sicherheits-Check
        if ($dish->category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403);
        }

        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'price' => 'required|integer|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'is_special' => 'nullable|boolean',
            'is_vegetarian' => 'nullable|boolean',
            'name_de' => 'required|string|max:255',
            'description_de' => 'nullable|string',
            'name_en' => 'nullable|string|max:255',
            'description_en' => 'nullable|string',
            'name_hu' => 'nullable|string|max:255',
            'description_hu' => 'nullable|string',
            'name_sk' => 'nullable|string|max:255',
            'description_sk' => 'nullable|string',
        ]);

        $imagePath = $dish->image_url;
        if ($request->hasFile('image')) {
            if ($imagePath) {
                Storage::disk('public')->delete($imagePath);
            }
            $imagePath = $request->file('image')->store('dishes', 'public');
        }

        $dish->update([
            'category_id' => $validated['category_id'],
            'price' => $validated['price'],
            'image_url' => $imagePath,
            'is_special' => $request->has('is_special'),
            'is_vegetarian' => $request->has('is_vegetarian'),
        ]);

        $this->updateTranslations($dish, $validated);

        return redirect()->route('dishes.index')->with('success', 'Gericht erfolgreich aktualisiert!');
    }

    public function destroy(Dish $dish)
    {
        // Sicherheits-Check
        if ($dish->category->restaurant_id !== Auth::user()->restaurant->id) {
            abort(403);
        }

        if ($dish->image_url) {
            Storage::disk('public')->delete($dish->image_url);
        }
        $dish->delete();
        return redirect()->route('dishes.index')->with('success', 'Gericht erfolgreich gelöscht!');
    }

    // Private Hilfsfunktion, um Code-Wiederholung zu vermeiden
    private function updateTranslations(Dish $dish, array $validatedData)
    {
        $translations = [
            'de' => ['name' => $validatedData['name_de'], 'description' => $validatedData['description_de'] ?? null],
            'en' => ['name' => $validatedData['name_en'] ?? null, 'description' => $validatedData['description_en'] ?? null],
            'hu' => ['name' => $validatedData['name_hu'] ?? null, 'description' => $validatedData['description_hu'] ?? null],
            'sk' => ['name' => $validatedData['name_sk'] ?? null, 'description' => $validatedData['description_sk'] ?? null],
        ];

        foreach ($translations as $locale => $data) {
            if (!empty($data['name'])) {
                $dish->translations()->updateOrCreate(
                    ['locale' => $locale],
                    ['name' => $data['name'], 'description' => $data['description']]
                );
            }
        }
    }
}