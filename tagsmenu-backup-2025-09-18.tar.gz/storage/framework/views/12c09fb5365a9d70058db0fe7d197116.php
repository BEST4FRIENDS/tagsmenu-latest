<!DOCTYPE html>
<html lang="de" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($restaurant->name); ?> - Speisekarte</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-[#100F0F] text-gray-200" x-data="{ currentLang: 'de', activeFilter: 'all' }">

    <div class="max-w-4xl mx-auto">

        <header class="text-center p-6 bg-[#181717] rounded-b-xl shadow-lg">
            <?php if($restaurant->logo_url): ?>
                <img src="<?php echo e($restaurant->logo_url); ?>" alt="<?php echo e($restaurant->name); ?> Logo" class="mx-auto h-24 w-auto mb-4">
            <?php else: ?>
                <h1 class="text-4xl font-bold text-white"><?php echo e($restaurant->name); ?></h1>
            <?php endif; ?>
        </header>

        <div class="p-4">
            
            <div class="flex justify-between items-center my-6">
                <div class="flex space-x-2">
                    <button @click="activeFilter = 'all'" class="px-3 py-1.5 rounded-full text-sm font-semibold transition-colors" :class="{'bg-white text-gray-900': activeFilter === 'all', 'bg-gray-700 text-gray-300 hover:bg-gray-600': activeFilter !== 'all'}">Alle</button>
                    <button @click="activeFilter = 'food'" class="px-3 py-1.5 rounded-full text-sm font-semibold transition-colors" :class="{'bg-white text-gray-900': activeFilter === 'food', 'bg-gray-700 text-gray-300 hover:bg-gray-600': activeFilter !== 'food'}">Speisen</button>
                    <button @click="activeFilter = 'drinks'" class="px-3 py-1.5 rounded-full text-sm font-semibold transition-colors" :class="{'bg-white text-gray-900': activeFilter === 'drinks', 'bg-gray-700 text-gray-300 hover:bg-gray-600': activeFilter !== 'drinks'}">Getränke</button>
                </div>
                <div class="flex items-center bg-gray-700 rounded-full p-1 text-sm">
                    <?php
                        $availableLangs = $restaurant->categories->flatMap(fn($category) => $category->translations)->pluck('locale')->unique()->sort();
                    ?>
                    <?php $__currentLoopData = $availableLangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button @click="currentLang = '<?php echo e($lang); ?>'" 
                                class="px-3 py-1 rounded-full font-semibold transition-colors duration-200" 
                                :class="{ 'bg-white text-gray-900 shadow': currentLang === '<?php echo e($lang); ?>', 'text-gray-400': currentLang !== '<?php echo e($lang); ?>' }">
                            <?php echo e(strtoupper($lang)); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <nav class="flex flex-wrap justify-center gap-2 mb-10">
                <?php $__currentLoopData = $restaurant->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#category-<?php echo e($category->id); ?>" class="px-4 py-2 bg-gray-700 text-gray-300 rounded-full text-sm font-semibold hover:bg-gray-600">
                        <span x-text="<?php echo e(json_encode($category->translations->pluck('name', 'locale')->all())); ?>[currentLang] || '<?php echo e($category->translations->firstWhere('locale', 'de')->name ?? ''); ?>'"></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>

            <main>
                <?php $__currentLoopData = $restaurant->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isDrinkCategory = Str::contains(strtolower($category->translations->firstWhere('locale', 'de')->name ?? ''), ['getränke', 'drinks', 'beverages', 'softdrinks', 'wein', 'bier']);
                    ?>
                    <section x-show="activeFilter === 'all' || (activeFilter === 'food' && !<?php echo e($isDrinkCategory ? 'true' : 'false'); ?>) || (activeFilter === 'drinks' && <?php echo e($isDrinkCategory ? 'true' : 'false'); ?>)" id="category-<?php echo e($category->id); ?>" class="mb-10">
                        <h2 class="text-3xl font-bold text-center mb-6 text-white"
                            x-text="<?php echo e(json_encode($category->translations->pluck('name', 'locale')->all())); ?>[currentLang] || '<?php echo e($category->translations->firstWhere('locale', 'de')->name ?? ''); ?>'">
                        </h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <?php $__currentLoopData = $category->dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($dish->is_available): ?>
                                    <div class="bg-[#181717] rounded-xl shadow-lg overflow-hidden">
                                        <?php if($dish->image_url): ?>
                                            <img src="<?php echo e(asset('storage/' . $dish->image_url)); ?>" alt="Bild von <?php echo e($dish->translations->firstWhere('locale', 'de')->name); ?>" class="w-full h-48 object-cover">
                                        <?php endif; ?>
                                        <div class="p-4">
                                            <div class="flex justify-between items-start">
                                                <h3 class="font-bold text-lg text-white"
                                                    x-text="<?php echo e(json_encode($dish->translations->pluck('name', 'locale')->all())); ?>[currentLang] || '<?php echo e($dish->translations->firstWhere('locale', 'de')->name ?? ''); ?>'">
                                                </h3>
                                                <div class="font-bold text-lg whitespace-nowrap pl-4 text-gray-300">
                                                    <?php echo e(number_format($dish->price, 0, ',', '.')); ?> Ft
                                                </div>
                                            </div>
                                            <p class="text-gray-400 text-sm mt-1"
                                               x-text="<?php echo e(json_encode($dish->translations->pluck('description', 'locale')->all())); ?>[currentLang] || '<?php echo e($dish->translations->firstWhere('locale', 'de')->description ?? ''); ?>'">
                                            </p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </main>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\biocl\Desktop\tagsmenu-app\resources\views/public/menu.blade.php ENDPATH**/ ?>