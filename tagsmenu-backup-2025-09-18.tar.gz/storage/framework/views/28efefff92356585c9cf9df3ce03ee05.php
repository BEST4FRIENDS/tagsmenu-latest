<div class="bg-gray-800 p-6 rounded-lg">
    <h3 class="font-semibold text-lg mb-4 text-blue-400">Schnell-Aktionen: Verfügbarkeit</h3>
    <div class="space-y-3 max-h-64 overflow-y-auto">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center justify-between p-2 bg-gray-700 rounded-md">
                <span class="text-sm font-medium <?php echo e(!$dish->is_available ? 'opacity-50' : ''); ?>">
                    <?php echo e($dish->translations->firstWhere('locale', 'de')->name ?? 'Gericht ohne Namen'); ?>

                </span>
                <div class="flex items-center space-x-2">
                    <span class="text-xs font-semibold <?php echo e($dish->is_available ? 'text-green-400' : 'text-red-400'); ?>">
                        <?php echo e($dish->is_available ? 'Verfügbar' : 'Ausverkauft'); ?>

                    </span>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" <?php if($dish->is_available): ?> checked <?php endif; ?> wire:click="toggleAvailability(<?php echo e($dish->id); ?>)" class="sr-only peer">
                      <div class="w-9 h-5 bg-gray-600 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500 text-sm">Noch keine Gerichte zum Verwalten vorhanden.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH C:\Users\biocl\Desktop\tagsmenu-app\resources\views/livewire/quick-actions.blade.php ENDPATH**/ ?>