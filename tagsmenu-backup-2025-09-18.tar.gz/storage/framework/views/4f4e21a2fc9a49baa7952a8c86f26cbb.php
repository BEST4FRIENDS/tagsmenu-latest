

<?php $__env->startSection('title', 'Kundenverwaltung'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold text-white">Kundenverwaltung (Superadmin)</h2>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 rounded-lg mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-gray-800 p-4 rounded-lg">
        <div class="overflow-x-auto">
            <table class="min-w-full">
                <thead>
                    <tr>
                        <th class="px-6 py-3 border-b-2 border-gray-700 text-left text-xs font-medium text-gray-400 uppercase">Restaurant & Besitzer</th>
                        <th class="px-6 py-3 border-b-2 border-gray-700 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                        <th class="px-6 py-3 border-b-2 border-gray-700 text-left text-xs font-medium text-gray-400 uppercase">Abonnement-Plan</th>
                        <th class="px-6 py-3 border-b-2 border-gray-700 text-left text-xs font-medium text-gray-400 uppercase">Abo-Status</th>
                        <th class="px-6 py-3 border-b-2 border-gray-700 text-left text-xs font-medium text-gray-400 uppercase">Registriert seit</th>
                        <th class="px-6 py-3 border-b-2 border-gray-700"></th>
                    </tr>
                </thead>
                <tbody class="bg-gray-800 text-white">
                    <?php $__empty_1 = true; $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $user = $restaurant->user;
                        ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700">
                                <div class="font-bold"><?php echo e($restaurant->name); ?></div>
                                <div class="text-sm text-gray-400"><?php echo e($user->name ?? 'N/A'); ?> (<?php echo e($user->email ?? 'N/A'); ?>)</div>
                            </td>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($restaurant->status === 'active' ? 'bg-green-500 text-green-100' : 'bg-red-500 text-red-100'); ?>">
                                    <?php echo e($restaurant->status === 'active' ? 'Aktiv' : 'Gesperrt'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700">
                                <?php if($user && $user->subscribed('default')): ?>
                                    <span class="font-semibold"><?php echo e($user->getPlanName()); ?></span>
                                <?php else: ?>
                                    <span class="text-gray-500">Kein Plan</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700">
                                <?php if($user && $user->subscribed('default')): ?>
                                    <?php $subscription = $user->subscription('default'); ?>
                                    <span class="font-semibold <?php echo e($subscription->stripe_status === 'active' ? 'text-green-400' : 'text-red-400'); ?>">
                                        <?php echo e(ucfirst($subscription->stripe_status)); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-500">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700 text-sm text-gray-400">
                                <?php echo e($restaurant->created_at->format('d.m.Y')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-700 text-right text-sm font-medium">
                                <div class="flex items-center justify-end space-x-4">
                                    <a href="<?php echo e(route('superadmin.clients.edit', ['restaurant' => $restaurant])); ?>" class="text-indigo-400 hover:text-indigo-300">Bearbeiten</a>
                                    
                                    
                                    <form action="<?php echo e(route('superadmin.clients.destroy', ['restaurant' => $restaurant])); ?>" method="POST" onsubmit="return confirm('Sind Sie sicher, dass Sie diesen Kunden endgültig löschen möchten? Alle seine Daten gehen verloren.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?> 
                                        <button type="submit" class="text-red-500 hover:text-red-400">Löschen</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center border-b border-gray-700 text-gray-400">
                                Es haben sich noch keine Kunden registriert.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\biocl\Desktop\tagsmenu-app\resources\views/superadmin/clients/index.blade.php ENDPATH**/ ?>