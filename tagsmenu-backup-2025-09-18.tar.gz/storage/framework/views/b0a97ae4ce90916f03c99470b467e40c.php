<?php $__env->startSection('title', 'Speisekarten-Verwaltung'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold text-white">Speisekarten-Verwaltung</h2>
        <a href="<?php echo e(route('dishes.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center">
            <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
            <span>Neues Gericht</span>
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-4 rounded-lg mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-gray-800 p-4 rounded-lg mb-6">
            <h3 class="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">
                <?php echo e($category->translations->firstWhere('locale', 'de')->name ?? "Kategorie #{$category->id}"); ?>

            </h3>
            <div class="space-y-2">
                <?php $__empty_2 = true; $__currentLoopData = $category->dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <div class="flex items-center justify-between p-3 bg-gray-700 rounded-md">
                        <div class="flex items-center">
                            <?php if($dish->image_url): ?>
                                <img src="<?php echo e(asset('storage/' . $dish->image_url)); ?>" class="w-12 h-12 object-cover rounded-md mr-4">
                            <?php endif; ?>
                            <span class="font-medium">
                                <?php echo e($dish->translations->firstWhere('locale', 'de')->name ?? 'Gericht ohne Namen'); ?>

                            </span>
                        </div>
                        <div class="flex items-center space-x-4">
                            <a href="<?php echo e(route('dishes.edit', $dish)); ?>" class="text-gray-400 hover:text-white" title="Bearbeiten">
                                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L14.732 3.732z"/></svg>
                            </a>
                            <form action="<?php echo e(route('dishes.destroy', $dish)); ?>" method="POST" onsubmit="return confirm('Sind Sie sicher?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:text-red-400" title="Löschen">
                                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <p class="text-gray-400">Noch keine Gerichte in dieser Kategorie.</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
         <div class="bg-gray-800 p-6 rounded-lg text-center">
            <p class="text-gray-400">Es wurden noch keine Kategorien erstellt.</p>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\biocl\Desktop\tagsmenu-app\resources\views/dishes/index.blade.php ENDPATH**/ ?>